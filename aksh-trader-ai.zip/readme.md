# Aksh's AI Trading Assistant

This is a custom AI-based trading dashboard that includes:

- Market overview
- Options tracker with Greeks
- Personalized BTST picks
- AI-powered live chart commentary
- Trade confidence labeling